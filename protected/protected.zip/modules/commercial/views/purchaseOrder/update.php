<?php /** @var mixed $model */
/** @var mixed $model2 */
/** @var mixed $model3 */
$this->renderPartial('_form2', array('model' => $model, 'model2' => $model2, 'model3' => $model3,)); ?>