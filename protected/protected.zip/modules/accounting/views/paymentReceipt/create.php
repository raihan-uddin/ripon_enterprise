<?php
/* @var $this PaymentReceiptController */
/* @var $model PaymentReceipt */
/* @var $model2 Suppliers */
?>

<?php $this->renderPartial('_form', array('model' => $model, 'model2' => $model2, 'id' => $id,)); ?>