<?php
/* @var $this ExpenseController */
/* @var $model Expense */

$this->renderPartial('_form2', array('model' => $model));
?>