<?php
/* @var $this ExpenseController */
/* @var $model Expense */
/* @var $model2 ExpenseDetails */

$this->renderPartial('_form', array('model' => $model, 'model2' => $model2)); ?>