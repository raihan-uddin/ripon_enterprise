<?php

class PaymentReceiptController extends Controller
{
    /**
     * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
     * using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout = '//layouts/column1';
    public $defaultAction = 'admin';

    /**
     * @return array action filters
     */
    public function filters()
    {
        return array(
            'rights',
        );
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     * @return array access control rules
     */
    public function accessRules()
    {
        return array();
    }


    /**
     * Creates a new model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     */

    public function actionCreate($id)
    {
        $model = new PaymentReceipt();
        $model2 = Suppliers::model()->findByPk($id);

        // Uncomment the following line if AJAX validation is needed
        $this->performAjaxValidation($model);


        if (isset($_POST['PaymentReceipt'])) {
            $model->attributes = $_POST['PaymentReceipt'];
            $model->max_sl_no = PaymentReceipt::maxSlNo();
            $model->order_id = 0;
            $model->amount = 0;
            $model->pr_no = "PR-" . date('y') . "-" . date('m') . "-" . str_pad($model->max_sl_no, 5, "0", STR_PAD_LEFT);
            if ($model->validate()) {
                $order_id_arr = [];
                foreach ($_POST['PaymentReceipt']['amount'] as $key => $amount) {
                    $rem_amount = $_POST['PaymentReceipt']['rem_amount'][$key];
                    $order_id = $_POST['PaymentReceipt']['order_id'][$key];
                    if ($amount > 0) {
                        $model2 = new PaymentReceipt();
                        $model2->date = $model->date;
                        $model2->payment_type = $model->payment_type;
                        $model2->supplier_id = $model->supplier_id;
                        $model2->order_id = $order_id;
                        $model2->max_sl_no = $model->max_sl_no;
                        $model2->pr_no = $model->pr_no;
                        $model2->amount = $amount;
                        $model2->bank_id = $model->bank_id;
                        $model2->cheque_no = $model->cheque_no;
                        $model2->remarks = $model->remarks;
                        $model2->cheque_date = $model->cheque_date;
                        if (!$model2->save()) {
                            var_dump($model2->getErrors());
                            exit;
                        }
                        $order_id_arr[] = $order_id;
                    }
                }
                $criteria = new CDbCriteria();
                $criteria->addInCondition('id', $order_id_arr);
                $data = PurchaseOrder::model()->findAll($criteria);
                if ($data) {
                    foreach ($data as $dt) {
                        $grand_total = $dt->grand_total;
                        $total_mr = PaymentReceipt::model()->totalPaidAmountOfThisOrder($dt->id);
                        $rem = $grand_total - $total_mr;
                        if ($total_mr >= $grand_total) {
                            $dt->is_paid = PurchaseOrder::PAID;
                            $dt->save();
                        }
                    }
                }
                $criteria = new CDbCriteria;
                $criteria->select = "SUM(amount) as amount, supplier_id, date, pr_no, bank_id, cheque_no, cheque_date, remarks, created_by";
                $criteria->addColumnCondition(['supplier_id' => $model->supplier_id, 'pr_no' => $model->pr_no]);
                $criteria->group = 'supplier_id, pr_no';
                $dataMr = PaymentReceipt::model()->findAll($criteria);
                echo CJSON::encode(array(
                    'status' => 'success',
                    'soReportInfo' => $this->renderPartial('voucherPreview', array('data' => $dataMr, 'new' => true), true, true), //
                ));
                Yii::app()->end();
            } else {
                $error = CActiveForm::validate($model);
                $error2 = CActiveForm::validate($model2);
                if ($error != '[]')
                    echo $error;
                if ($error2 != '[]')
                    echo $error2;
                Yii::app()->end();
            }
        }


        $this->pageTitle = "PR CREATE";
        $this->render('create', array(
            'model' => $model,
            'model2' => $model2,
            'id' => $id,
        ));
    }

    /**
     * Performs the AJAX validation.
     * @param PaymentReceipt $model the model to be validated
     */
    protected function performAjaxValidation($model)
    {
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'payment-receipt-form') {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }
    }

    /**
     * Deletes a particular model.
     * If deletion is successful, the browser will be redirected to the 'admin' page.
     * @param integer $id the ID of the model to be deleted
     */
    public function actionDelete($id)
    {
        $data = $this->loadModel($id);
        if ($data) {
            $orderId = $data->order_id;
            $invoice = PurchaseOrder::model()->findByPk($orderId);
            if (!$invoice)
                throw new CHttpException(404, 'The requested page does not exist.');

            if (!$this->loadModel($id)->delete())
                throw new CHttpException(404, 'The requested page does not exist.');

            $currentCollection = PaymentReceipt::model()->totalPaidAmountOfThisOrder($orderId);

            if ($invoice) {
                $invoice->is_paid = $currentCollection >= $invoice->grand_total ? PurchaseOrder::PAID : PurchaseOrder::DUE;
                $invoice->save();
            }
        }

        // if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
        if (!isset($_GET['ajax']))
            $this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
    }

    /**
     * Returns the data model based on the primary key given in the GET variable.
     * If the data model is not found, an HTTP exception will be raised.
     * @param integer $id the ID of the model to be loaded
     * @return PaymentReceipt the loaded model
     * @throws CHttpException
     */
    public function loadModel($id)
    {
        $model = PaymentReceipt::model()->findByPk($id);
        if ($model === null)
            throw new CHttpException(404, 'The requested page does not exist.');
        return $model;
    }

    /**
     * Manages all models.
     */
    public function actionAdmin()
    {
        $model = new PaymentReceipt('search');
        $model->unsetAttributes();  // clear any default values
        if (isset($_GET['PaymentReceipt']))
            $model->attributes = $_GET['PaymentReceipt'];


        $this->pageTitle = "PAYMENT RECEIPT MANAGE";
        $this->render('admin', array(
            'model' => $model,
        ));
    }

    /**
     * Manages all models.
     */
    public function actionAdminPaymentReceipt()
    {
        $model = new Suppliers('search');
        $model->unsetAttributes();  // clear any default values
        if (isset($_GET['Suppliers']))
            $model->attributes = $_GET['Suppliers'];

        $this->pageTitle = "SUPPLIER MANAGE";
        $this->render('adminPaymentReceipt', array(
            'model' => $model,
        ));
    }

    public function actionVoucherPreview()
    {
        $pr_no = isset($_POST['pr_no']) ? trim($_POST['pr_no']) : "";

        if (strlen($pr_no) > 0) {
            $criteria = new CDbCriteria;
            $criteria->select = "SUM(amount) as amount, supplier_id, date, pr_no, bank_id, cheque_no, cheque_date, remarks, created_by";
            $criteria->addColumnCondition(['pr_no' => $pr_no]);
            $criteria->group = 'supplier_id, pr_no';
            $data = PaymentReceipt::model()->findAll($criteria);
            if ($data) {
                echo $this->renderPartial("voucherPreview", array('data' => $data,), true, true);
            } else {
                header('Content-type: application/json');
                echo CJSON::encode(array(
                    'status' => 'error',
                ));
            }
            Yii::app()->end();
        } else {
            echo '<div class="alert alert-danger" role="alert">Please select  PR no!</div>';
        }
    }
}
