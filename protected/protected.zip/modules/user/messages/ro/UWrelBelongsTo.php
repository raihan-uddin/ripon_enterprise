<?php

return array(
	'Model Name'=>'Nume model',
	'Lable field name'=>'Eticheta nume camp',
	'Empty item name'=>'Nume element gol',
	'Profile model relation name'=>'Denumire model relational profil',
);
