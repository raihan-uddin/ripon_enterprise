<?php

return array(
	'Model Name'=>'Model Név',
	'Lable field name'=>'Elnevezés mező név',
	'Empty item name'=>'Üres elem név',
	'Profile model relation name'=>'Profil model reláció név',
);
